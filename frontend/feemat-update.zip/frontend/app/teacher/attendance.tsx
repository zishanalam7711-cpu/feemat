import React, { useCallback, useMemo, useState } from "react";
import { View, Text, StyleSheet, FlatList, Pressable, ActivityIndicator, Alert } from "react-native";
import { useFocusEffect, useRouter } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { SPACING, RADIUS } from "@/src/lib/theme";
import { api } from "@/src/lib/api";
import { Avatar } from "@/src/components/Avatar";

const DARK = {
  bg: "#120A28",
  card: "#1E1440",
  border: "rgba(255,255,255,0.08)",
  text: "#FFFFFF",
  sub: "rgba(255,255,255,0.6)",
};

type Status = "present" | "absent" | "late" | "leave";
const STATUSES: { key: Status; label: string; color: string }[] = [
  { key: "present", label: "P", color: "#10B981" },
  { key: "absent", label: "A", color: "#EF4444" },
  { key: "late", label: "Late", color: "#F59E0B" },
  { key: "leave", label: "Leave", color: "#3B82F6" },
];

export default function AttendanceScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const [items, setItems] = useState<any[]>([]);
  const [marks, setMarks] = useState<Record<string, Status>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const today = new Date().toISOString().slice(0, 10);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res: any = await api("/teacher/students?filter=all&limit=200");
      setItems(res.items || []);
    } catch {}
    setLoading(false);
  }, []);
  useFocusEffect(useCallback(() => { load(); }, [load]));

  const counts = useMemo(() => {
    const c = { present: 0, absent: 0, late: 0, leave: 0 };
    Object.values(marks).forEach((m) => { c[m] += 1; });
    return c;
  }, [marks]);
  const markedCount = Object.keys(marks).length;

  const setOne = (id: string, st: Status) => setMarks((p) => ({ ...p, [id]: st }));
  const allPresent = () => {
    const m: Record<string, Status> = {};
    items.forEach((i) => { m[i.id] = "present"; });
    setMarks(m);
  };

  const save = async () => {
    if (markedCount === 0) { Alert.alert("Kuch mark nahi hua", "Pehle kisi student ki attendance lagao."); return; }
    setSaving(true);
    try {
      await Promise.all(
        Object.entries(marks).map(([id, status]) =>
          api(`/connections/${id}/attendance`, { method: "POST", body: { date: today, status } })
        )
      );
      Alert.alert("Save ho gaya", `${markedCount} students ki attendance save ho gayi.`, [{ text: "OK", onPress: () => router.back() }]);
    } catch (e: any) {
      Alert.alert("Error", e?.message || "Save nahi hua, dobara try karo.");
    }
    setSaving(false);
  };

  return (
    <View style={{ flex: 1, backgroundColor: DARK.bg }}>
      <View style={[styles.header, { paddingTop: insets.top + SPACING.md }]}>
        <Pressable onPress={() => router.back()} hitSlop={12}><Ionicons name="arrow-back" size={22} color="#fff" /></Pressable>
        <View style={{ flex: 1 }}>
          <Text style={styles.title}>Attendance</Text>
          <Text style={styles.date}>{today}</Text>
        </View>
        <Pressable onPress={allPresent} style={styles.allBtn}>
          <Ionicons name="checkmark-done" size={16} color="#10B981" />
          <Text style={styles.allTxt}>All Present</Text>
        </Pressable>
      </View>

      <View style={styles.summary}>
        <Sum label="Present" v={counts.present} color="#10B981" />
        <Sum label="Absent" v={counts.absent} color="#EF4444" />
        <Sum label="Late" v={counts.late} color="#F59E0B" />
        <Sum label="Leave" v={counts.leave} color="#3B82F6" />
      </View>

      {loading ? (
        <View style={styles.center}><ActivityIndicator color="#A855F7" /></View>
      ) : items.length === 0 ? (
        <View style={styles.center}>
          <Ionicons name="people-outline" size={56} color="rgba(255,255,255,0.25)" />
          <Text style={{ color: DARK.sub, marginTop: 8 }}>Abhi koi student nahi hai.</Text>
        </View>
      ) : (
        <FlatList
          data={items}
          keyExtractor={(i) => i.id}
          contentContainerStyle={{ padding: SPACING.md, gap: SPACING.sm, paddingBottom: 120 }}
          renderItem={({ item }) => (
            <View style={styles.row}>
              <Avatar name={item.student?.name} uri={item.student?.photo_url} size={40} bg="rgba(168,85,247,0.2)" fg="#C4B5FD" />
              <View style={{ flex: 1 }}>
                <Text style={styles.name} numberOfLines={1}>{item.student?.name || "Student"}</Text>
                <Text style={styles.meta}>{item.admission_number}</Text>
              </View>
              <View style={styles.btns}>
                {STATUSES.map((s) => {
                  const on = marks[item.id] === s.key;
                  return (
                    <Pressable key={s.key} onPress={() => setOne(item.id, s.key)} style={[styles.chip, { borderColor: s.color }, on && { backgroundColor: s.color }]}>
                      <Text style={[styles.chipTxt, { color: on ? "#fff" : s.color }]}>{s.label}</Text>
                    </Pressable>
                  );
                })}
              </View>
            </View>
          )}
        />
      )}

      <View style={[styles.footer, { paddingBottom: insets.bottom + SPACING.md }]}>
        <Pressable onPress={save} disabled={saving} style={[styles.saveBtn, saving && { opacity: 0.6 }]}>
          {saving ? <ActivityIndicator color="#fff" /> : <Text style={styles.saveTxt}>Save Attendance ({markedCount})</Text>}
        </Pressable>
      </View>
    </View>
  );
}

function Sum({ label, v, color }: { label: string; v: number; color: string }) {
  return (
    <View style={styles.sumBox}>
      <Text style={[styles.sumV, { color }]}>{v}</Text>
      <Text style={styles.sumL}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, alignItems: "center", justifyContent: "center" },
  header: { flexDirection: "row", alignItems: "center", gap: SPACING.md, paddingHorizontal: SPACING.lg, paddingBottom: SPACING.md },
  title: { color: "#fff", fontSize: 22, fontWeight: "800" },
  date: { color: DARK.sub, fontSize: 12, marginTop: 2 },
  allBtn: { flexDirection: "row", alignItems: "center", gap: 4, paddingHorizontal: 10, paddingVertical: 6, borderRadius: 999, backgroundColor: "rgba(16,185,129,0.15)" },
  allTxt: { color: "#10B981", fontWeight: "700", fontSize: 12 },
  summary: { flexDirection: "row", gap: SPACING.sm, paddingHorizontal: SPACING.md, marginBottom: SPACING.sm },
  sumBox: { flex: 1, alignItems: "center", paddingVertical: SPACING.sm, borderRadius: RADIUS.md, backgroundColor: DARK.card, borderWidth: 1, borderColor: DARK.border },
  sumV: { fontSize: 18, fontWeight: "800" },
  sumL: { color: DARK.sub, fontSize: 11 },
  row: { flexDirection: "row", alignItems: "center", gap: SPACING.sm, padding: SPACING.sm, borderRadius: RADIUS.md, backgroundColor: DARK.card, borderWidth: 1, borderColor: DARK.border },
  name: { color: DARK.text, fontWeight: "700", fontSize: 14 },
  meta: { color: DARK.sub, fontSize: 11, marginTop: 2 },
  btns: { flexDirection: "row", gap: 4 },
  chip: { minWidth: 34, paddingHorizontal: 6, height: 30, borderRadius: 8, borderWidth: 1.5, alignItems: "center", justifyContent: "center" },
  chipTxt: { fontSize: 11, fontWeight: "800" },
  footer: { position: "absolute", left: 0, right: 0, bottom: 0, padding: SPACING.md, backgroundColor: DARK.bg, borderTopWidth: 1, borderTopColor: DARK.border },
  saveBtn: { height: 50, borderRadius: RADIUS.md, backgroundColor: "#7C3AED", alignItems: "center", justifyContent: "center" },
  saveTxt: { color: "#fff", fontWeight: "800", fontSize: 15 },
});
